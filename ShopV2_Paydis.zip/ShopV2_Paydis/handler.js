const { Function: Func, Logs, Scraper, Cooldown, Spam, InvCloud } = new(require('@neoxr/wb'))
const fs = require('fs')
const { promisify } = require('util')
const fetch = require('node-fetch')
const md5 = require('md5')
const path = './lib/database/produk.json'
const readFileAsync = promisify(fs.readFile)
const env = require('./config.json')
const cron = require('node-cron')
const schedule = require('node-schedule')
const cache = new(require('node-cache'))({
    stdTTL: env.cooldown
})
const cooldown = new Cooldown(env.cooldown)
const spam = new Spam({
    RESET_TIMER: env.cooldown,
    HOLD_TIMER: env.timeout,
    PERMANENT_THRESHOLD: env.permanent_threshold,
    NOTIFY_THRESHOLD: env.notify_threshold,
    BANNED_THRESHOLD: env.banned_threshold
})

// Membuat objek untuk menyimpan status pengiriman pesan untuk setiap nomor dan setiap unique code
const messageStatus = {};
const messageStatus2 = {};

module.exports = async(client, ctx) => {
    const { store, m, body, prefix, plugins, commands, args, command, text, prefixes, core } = ctx
    // const context = m.message[m.mtype] || m.message.viewOnceMessageV2.message[m.mtype]
    // process.env['E_MSG'] = context.contextInfo ? Number(context.contextInfo.expiration) : 0
    try {
        // "InvCloud" reduces RAM usage and minimizes errors during rewrite (according to recommendations/suggestions from Baileys)
        require('./lib/system/schema')(m, env), InvCloud(store)
        const groupSet = global.db.groups.find(v => v.jid === m.chat)
        const chats = global.db.chats.find(v => v.jid === m.chat)
        const users = global.db.users.find(v => v.jid === m.sender)
        const setting = global.db.setting
        const isSeller = (global.db.users.some(v => v.jid == m.sender) && global.db.users.find(v => v.jid == m.sender).seller)
        const isOwner = [client.decodeJid(client.user.id).replace(/@.+/, ''), env.owner, ...setting.owners].map(v => v + '@s.whatsapp.net').includes(m.sender)
        const isPrem = users && users.premium || isOwner
        const groupMetadata = m.isGroup ? await client.groupMetadata(m.chat) : {}
        const participants = m.isGroup ? groupMetadata.participants : [] || []
        const adminList = m.isGroup ? await client.groupAdmin(m.chat) : [] || []
        const isAdmin = m.isGroup ? adminList.includes(m.sender) : false
        const isBotAdmin = m.isGroup ? adminList.includes((client.user.id.split`:` [0]) + '@s.whatsapp.net') : false
        const blockList = typeof await(await client.fetchBlocklist()) != 'undefined' ? await(await client.fetchBlocklist()) : []
        const isSpam = spam.detection(client, m, {
            prefix,
            command,
            commands,
            users,
            cooldown,
            show: 'all', // choose 'all' or 'command-only'
            banned_times: users.ban_times,
            simple: false
        })
        if (!setting.online) client.sendPresenceUpdate('unavailable', m.chat)
        if (setting.online) {
            client.sendPresenceUpdate('available', m.chat)
        }
        if (setting.autoread) {
            client.readMessages([m.key])
        }
        if (m.isGroup && !isBotAdmin) {
            groupSet.localonly = false
        }
        if (!users || typeof users.limit === undefined) return global.db.users.push({
            jid: m.sender,
            banned: false,
            limit: env.limit,
            hit: 0,
            spam: 0
        })
        if (!setting.multiprefix) setting.noprefix = false
        if (setting.debug && !m.fromMe && isOwner) client.reply(m.chat, Func.jsonFormat(m), m)
        if (m.isGroup && !groupSet.stay && (new Date * 1) >= groupSet.expired && groupSet.expired != 0) {
            return client.reply(m.chat, Func.texted('italic', '🚩 Bot time has expired and will leave from this group, thank you.', null, {
                mentions: participants.map(v => v.id)
            })).then(async() => {
                groupSet.expired = 0
                await Func.delay(2000).then(() => client.groupLeave(m.chat))
            })
        }
        if (users && (new Date * 1) >= users.expired && users.expired != 0) {
            return client.reply(users.jid, Func.texted('italic', '🚩 Your premium package has expired, thank you for buying and using our service.')).then(async() => {
                users.premium = false
                users.expired = 0
                users.limit = env.limit
            })
        }
        if (users && (new Date * 1) >= users.expired_subdo && users.expired_subdo != 0) {
         return client.reply(users.jid, Func.texted('italic', '🚩 Your Seller Sub Domain has expired, thank you for buying and using our service.')).then(async () => {
            users.subdomain = false
            users.expired_subdo = 0
            users.limit = env.limit
         })
      }
        if (m.isGroup) groupSet.activity = new Date() * 1
        if (users) {
            users.name = m.pushName
            users.lastseen = new Date() * 1
        }
        if (chats) {
            chats.chat += 1
            chats.lastseen = new Date * 1
        }
        if (m.isGroup && !m.isBot && users && users.afk > -1) {
            client.reply(m.chat, `You are back online after being offline for : ${Func.texted('bold', Func.toTime(new Date - users.afk))}\n\n• ${Func.texted('bold', 'Reason')}: ${users.afkReason ? users.afkReason : '-'}`, m)
            users.afk = -1
            users.afkReason = ''
        }
        if (setting.auto_cekstatus) {
        // Schedule the job to run every 5 seconds
        const job = schedule.scheduleJob('*/5 * * * * *', async function() {
    try {
        // Baca data transaksi dari file JSON
        const transaksiData = await readFileAsync('./lib/database/transaksi.json', 'utf8');
        let transaksi = JSON.parse(transaksiData);

        // Daftar unique_code dari transaksi
        const uniqueCodes = Object.keys(transaksi);

        // Cek status pembayaran untuk setiap unique_code
        for (const uniqueCode of uniqueCodes) {
            // Mendapatkan nomor telepon dan balance dari data transaksi
            const { nomor, balance } = transaksi[uniqueCode];

            // Memeriksa status pembayaran menggunakan unique_code
            const status = await cekStatusPembayaran(uniqueCode);

            // Mengirim pesan ke nomor yang terkait dengan status pembayaran
            if (status === 'Success') {
                // Cek apakah nomor ini sudah menerima pesan untuk unique code ini atau belum
                if (!messageStatus[nomor]) {
                    // Jika belum, buat objek untuk menyimpan status pengiriman pesan untuk unique code ini
                    messageStatus[nomor] = {};
                }

                // Cek apakah unique code ini sudah dikirimkan kepada nomor ini atau belum
                if (!messageStatus[nomor][uniqueCode]) {
let po = global.db.users.find(v => v.jid === nomor + '@s.whatsapp.net')
                    // Jika belum, kirim pesan dan set status pengiriman pesan untuk unique code ini menjadi true
                    client.sendMessageModifyV2(nomor + '@c.us', `*❒  PEMBAYARAN SUKSES*

Pay Id : *${po.payid}*
Status : *Success ✅*
Unique Code: *${uniqueCode}*
Jumlah : *${po.jumlah}*
Total Pembayaran : *${po.total_pembayaran}*

Note : _${po.note}_

Create : *${po.create}*
Expired : *${po.payexpired}*

${global.footer}`, 'Successfully ✅', {
   title: env.bot_name,
   largeThumb: true,
   ads: true,
   thumbnail: 'https://i.ibb.co/Gx9YsJq/image.jpg',
   url: 'https://chat.whatsapp.com/HzaF888SGaMJhEq24wP29B'
})
                    messageStatus[nomor][uniqueCode] = true;

                    // Cari user berdasarkan nomor telepon
                    const user = global.db.users.find(v => v.jid === `${nomor}@s.whatsapp.net`);
                    // Memastikan user ditemukan sebelum mengakses propertinya
                    if (user) {
                        user.deposit = parseInt(balance);
                        user.status_deposit = false;
                        user.payid = '';
                        user.jumlah = '';
                        user.total_pembayaran = '';
                        user.note = '';
                        user.create = '';
                        user.payexpired = '';
                    }

                    // Hapus data unique_code dari transaksi jika statusnya sudah Success
                    delete transaksi[uniqueCode];

                    // Menulis kembali data transaksi setelah menghapus data unique_code yang statusnya sudah Success
                    fs.writeFileSync('./lib/database/transaksi.json', JSON.stringify(transaksi, null, 2));
                }
            }
        }
    } catch (error) {
        console.error('Error occurred while processing payment check:', error);
    }
})};
if (setting.auto_cekstatus) {
    // Schedule the job to run every 5 seconds
    const job = schedule.scheduleJob('*/5 * * * * *', async function() {
        try {
            // Baca data transaksi dari file JSON
            const transaksiData = await readFileAsync('./lib/database/beli.json', 'utf8');
            let transaksi = JSON.parse(transaksiData);

            // Daftar unique_code dari transaksi
            const uniqueCodes = Object.keys(transaksi);

            // Cek status pembayaran untuk setiap unique_code
            for (const uniqueCode of uniqueCodes) {
                // Mendapatkan nomor telepon dan amount dari data transaksi
                const { nomor, amount, code_produk } = transaksi[uniqueCode];

                // Memeriksa status pembayaran menggunakan unique_code
                const status = await cekStatusPembayaran(uniqueCode);

                // Mengirim pesan ke nomor yang terkait dengan status pembayaran
                if (status === 'Success') {
                    // Cek apakah nomor ini sudah menerima pesan untuk unique code ini atau belum
                    if (!messageStatus2[nomor]) {
                        // Jika belum, buat objek untuk menyimpan status pengiriman pesan untuk unique code ini
                        messageStatus2[nomor] = {};
                    }

                    // Cek apakah unique code ini sudah dikirimkan kepada nomor ini atau belum
                    if (!messageStatus2[nomor][uniqueCode]) {
                        // Baca pesan dari file code_produk
                        const produkData = await readFileAsync(`./lib/database/data/${code_produk}.json`, 'utf8');
                        let pesanList = JSON.parse(produkData);

                        // Kirim pesan sebanyak amount
                        for (let i = 0; i < amount; i++) {
                            if (pesanList.length > 0) {
                                const pesan = pesanList.shift(); // Ambil pesan pertama dari list

                                // Kirim pesan melalui client WhatsApp
                                client.sendMessageModifyV2(nomor + '@c.us', pesan, 'Successfully ✅', {
                                    title: env.bot_name,
                                    largeThumb: true,
                                    ads: true,
                                    thumbnail: 'https://i.ibb.co/Gx9YsJq/image.jpg',
                                    url: 'https://chat.whatsapp.com/HzaF888SGaMJhEq24wP29B'
                                });
                            }
                        }

const user = global.db.users.find(v => v.jid === `${nomor}@s.whatsapp.net`);
user.deposit = 0

                        // Set status pengiriman pesan untuk unique code ini menjadi true
                        messageStatus2[nomor][uniqueCode] = true;

                        // Tulis kembali pesan yang tersisa ke file code_produk
                        fs.writeFileSync(`./lib/database/data/${code_produk}.json`, JSON.stringify(pesanList, null, 2));

                        // Hapus data unique_code dari transaksi jika statusnya sudah Success
                        delete transaksi[uniqueCode];
                        
// Fungsi untuk mengurangi stok
function kurangiStok(code, kurang) {
    // Membaca file JSON
    fs.readFile(path, 'utf8', (err, data) => {
        if (err) {
            console.error("Error reading file:", err);
            return;
        }

        let result = JSON.parse(data);

        // Cari produk berdasarkan kode produk
        for (let key in result.produk) {
            if (key.split('°')[2] === code.toUpperCase()) {
                // Mengurangi stok
                if (result.produk[key].stok >= kurang) {
                    result.produk[key].stok -= kurang;
                    result.produk[key].stok_terjual += kurang;
                    console.log(`Stok produk ${key} dikurangi ${amount}. Stok sekarang: ${result.produk[key].stok}`);
                } else {
                    console.error("Stok tidak cukup untuk dikurangi.");
                    return;
                }

                // Menyimpan kembali data ke file JSON
                fs.writeFile(path, JSON.stringify(result, null, 2), (err) => {
                    if (err) {
                        console.error("Error writing file:", err);
                        return;
                    }
                    console.log("Data berhasil diperbarui dan disimpan.");
                });
                return;
            }
        }

        console.error("Produk tidak ditemukan.");
    });
}

kurangiStok(code_produk, amount);

                        // Menulis kembali data transaksi setelah menghapus data unique_code yang statusnya sudah Success
                        fs.writeFileSync('./lib/database/beli.json', JSON.stringify(transaksi, null, 2));
                    }
                }
            }
        } catch (error) {
            console.error('Error occurred while processing payment check:', error);
        }
    });
}
        cron.schedule('00 00 * * *', () => {
            setting.lastReset = new Date * 1
            global.db.users.filter(v => v.limit < env.limit && !v.premium).map(v => v.limit = env.limit)
            Object.entries(global.db.statistic).map(([_, prop]) => prop.today = 0)
        }, {
            scheduled: true,
            timezone: process.env.TZ
        })
        if (m.isGroup && !m.fromMe) {
            let now = new Date() * 1
            if (!groupSet.member[m.sender]) {
                groupSet.member[m.sender] = {
                    lastseen: now,
                    warning: 0
                }
            } else {
                groupSet.member[m.sender].lastseen = now
            }
        }
      if (isSpam && /(BANNED|NOTIFY|TEMPORARY)/.test(isSpam.state)) return client.reply(m.chat, Func.texted('bold', `🚩 ${isSpam.msg}`), m)
      if (isSpam && /HOLD/.test(isSpam.state)) return
      if (body && !setting.self && !setting.noprefix && !core.corePrefix.includes(core.prefix) && commands.includes(core.command) && !env.evaluate_chars.includes(core.command)) return client.reply(m.chat, `🚩 *Prefix needed!*, this bot uses prefix : *[ ${setting.multiprefix ? setting.prefix.join(', ') : setting.onlyprefix} ]*\n\n➠ ${setting.multiprefix ? setting.prefix[0] : setting.onlyprefix}${core.command} ${text || ''}`, m)
      if (body && !setting.self && core.prefix != setting.onlyprefix && commands.includes(core.command) && !setting.multiprefix && !env.evaluate_chars.includes(core.command)) return client.reply(m.chat, `🚩 *Incorrect prefix!*, this bot uses prefix : *[ ${setting.onlyprefix} ]*\n\n➠ ${setting.onlyprefix + core.command} ${text || ''}`, m)
      const matcher = Func.matcher(command, commands).filter(v => v.accuracy >= 60)
      if (prefix && !commands.includes(command) && matcher.length > 0 && !setting.self) {
    const suggestions = matcher.filter(v => v.accuracy < 100); // Filter hanya yang accuracy-nya kurang dari 100%
    if (suggestions.length > 0 && (!m.isGroup || (m.isGroup && !groupSet.mute))) {
        const suggestionText = suggestions.map(v => `➠ *${prefix ? prefix : ''}${v.string}* (${v.accuracy}%)`).join('\n');
        client.sendMessageModify(m.chat, `🚩 Fitur Tidak Ada, Coba Rekomendasi Berikut :\n\n${matcher.map(v => '➠ *' + (prefix ? prefix : '') + v.string + '* (' + v.accuracy + '%)').join('\n')}`, m, {
               ads: false,
               largeThumb: true,
               thumbnail: await Func.fetchBuffer('https://iili.io/JolUThJ.jpg'),
               url: 'https://chat.whatsapp.com/HzaF888SGaMJhEq24wP29B'
            })
    }
}
      if (body && prefix && commands.includes(command) || body && !prefix && commands.includes(command) && setting.noprefix || body && !prefix && commands.includes(command) && env.evaluate_chars.includes(command)) {
         if (setting.error.includes(command)) return client.reply(m.chat, Func.texted('bold', `🚩 Command _${(prefix ? prefix : '') + command}_ disabled.`), m)
         if (!m.isGroup && env.blocks.some(no => m.sender.startsWith(no))) return client.updateBlockStatus(m.sender, 'block')
         if (commands.includes(command)) {
            users.hit += 1
            users.usebot = new Date() * 1
            Func.hitstat(command, m.sender)
         }
         const is_commands = Object.fromEntries(Object.entries(plugins).filter(([name, prop]) => prop.run.usage))
         for (let name in is_commands) {
            const cmd = is_commands[name].run
            const turn = cmd.usage instanceof Array ? cmd.usage.includes(command) : cmd.usage instanceof String ? cmd.usage == command : false
            const turn_hidden = cmd.hidden instanceof Array ? cmd.hidden.includes(command) : cmd.hidden instanceof String ? cmd.hidden == command : false
            if (!turn && !turn_hidden) continue
            if (m.isBot || m.chat.endsWith('broadcast') || /edit/.test(m.mtype)) continue
            if (setting.self && !isOwner && !m.fromMe) continue
            if (!m.isGroup && !['owner'].includes(name) && chats && !isPrem && !users.banned && new Date() * 1 - chats.lastchat < env.timeout) continue
            if (!m.isGroup && !['owner', 'menfess', 'scan', 'verify', 'payment', 'premium'].includes(name) && chats && !isPrem && !users.banned && setting.groupmode) {
               client.sendMessageModify(m.chat, `⚠️ Using bot in private chat only for premium user, want to upgrade to premium plan ? send *${prefixes[0]}premium* to see benefit and prices.`, m, {
                  largeThumb: true,
                  thumbnail: 'https://telegra.ph/file/0b32e0a0bb3b81fef9838.jpg',
                  url: setting.link
               }).then(() => chats.lastchat = new Date() * 1)
               continue
            }
            if (!['me', 'owner', 'exec'].includes(name) && users && (users.banned || new Date - users.ban_temporary < env.timeout)) continue
            if (m.isGroup && !['activation', 'groupinfo'].includes(name) && groupSet.mute) continue
            if (cmd.cache && cmd.location) {
               Func.updateFile(cmd.location)
            }
            if (cmd.owner && !isOwner) {
               client.reply(m.chat, global.status.owner, m)
               continue
            }
            if (cmd.restrict && !isPrem && !isOwner && text && new RegExp('\\b' + setting.toxic.join('\\b|\\b') + '\\b').test(text.toLowerCase())) {
               client.reply(m.chat, `⚠️ You violated the *Terms & Conditions* of using bots by using blacklisted keywords, as a penalty for your violation being blocked and banned.`, m).then(() => {
                  users.banned = true
                  client.updateBlockStatus(m.sender, 'block')
               })
               continue
            }
            if (cmd.premium && !isPrem) {
               client.reply(m.chat, global.status.premium, m)
               continue
            }
            if (cmd.seller && !isSeller) {
               client.reply(m.chat, global.status.seller, m)
               continue
            }
            if (cmd.limit && users.limit < 1) {
               client.reply(m.chat, `⚠️ You reached the limit and will be reset at 00.00\n\nTo get more limits upgrade to premium plans.`, m).then(() => users.premium = false)
               continue
            }
            if (cmd.limit && users.limit > 0) {
               const limit = cmd.limit.constructor.name == 'Boolean' ? 1 : cmd.limit
               if (users.limit >= limit) {
                  users.limit -= limit
               } else {
                  client.reply(m.chat, Func.texted('bold', `⚠️ Your limit is not enough to use this feature.`), m)
                  continue
               }
            }
            if (cmd.group && !m.isGroup) {
               client.reply(m.chat, global.status.group, m)
               continue
            } else if (cmd.botAdmin && !isBotAdmin) {
               client.reply(m.chat, global.status.botAdmin, m)
               continue
            } else if (cmd.admin && !isAdmin) {
               client.reply(m.chat, global.status.admin, m)
               continue
            }
            if (cmd.private && m.isGroup) {
               client.reply(m.chat, global.status.private, m)
               continue
            }
            cmd.async(m, { client, args, text, isPrefix: prefix, prefixes, command, groupMetadata, participants, users, chats, groupSet, setting, isOwner, isAdmin, isSeller, isBotAdmin, plugins, blockList, env, ctx, store, Func, Scraper })
            break
         }
      } else {
         const is_events = Object.fromEntries(Object.entries(plugins).filter(([name, prop]) => !prop.run.usage))
         for (let name in is_events) {
            let event = is_events[name].run
            if (m.fromMe || m.chat.endsWith('broadcast') || /pollUpdate/.test(m.mtype)) continue
            if (!m.isGroup && env.blocks.some(no => m.sender.startsWith(no))) return client.updateBlockStatus(m.sender, 'block')
            if (setting.self && !['menfess_ev', 'anti_link', 'anti_tagall', 'anti_virtex', 'filter'].includes(event.pluginName) && !isOwner && !m.fromMe) continue
            if (!['anti_link', 'anti_tagall', 'anti_virtex', 'filter'].includes(name) && users && (users.banned || new Date - users.ban_temporary < env.timeout)) continue
            if (!['anti_link', 'anti_tagall', 'anti_virtex', 'filter'].includes(name) && groupSet && groupSet.mute) continue
            if (!m.isGroup && !['menfess_ev', 'chatbot', 'auto_download'].includes(name) && chats && !isPrem && !users.banned && new Date() * 1 - chats.lastchat < env.timeout) continue
            if (!m.isGroup && setting.groupmode && !['system_ev', 'menfess_ev', 'chatbot', 'auto_download'].includes(name) && !isPrem) return client.sendMessageModify(m.chat, `⚠️ Using bot in private chat only for premium user, want to upgrade to premium plan ? send *${prefixes[0]}premium* to see benefit and prices.`, m, {
               largeThumb: true,
               thumbnail: await Func.fetchBuffer('https://telegra.ph/file/0b32e0a0bb3b81fef9838.jpg'),
               url: setting.link
            }).then(() => chats.lastchat = new Date() * 1)
            if (event.cache && event.location) {
               Func.updateFile(event.location)
            }
            if (event.error) continue
            if (event.owner && !isOwner) continue
            if (event.group && !m.isGroup) continue
            if (event.limit && !event.game && users.limit < 1 && body && Func.generateLink(body) && Func.generateLink(body).some(v => Func.socmed(v))) return client.reply(m.chat, `⚠️ You reached the limit and will be reset at 00.00\n\nTo get more limits upgrade to premium plan.`, m).then(() => {
               users.premium = false
               users.expired = 0
            })
            if (event.botAdmin && !isBotAdmin) continue
            if (event.admin && !isAdmin) continue
            if (event.private && m.isGroup) continue
            if (event.download && (!setting.autodownload || (body && env.evaluate_chars.some(v => body.startsWith(v))))) continue
            event.async(m, { client, body, prefixes, groupMetadata, participants, users, chats, groupSet, setting, isOwner, isSeller, isAdmin, isBotAdmin, plugins, blockList, env, ctx, store, Func, Scraper })
         }
      }
   } catch (e) {
      if (/(undefined|overlimit|timed|timeout|users|item|time)/ig.test(e.message)) return
      console.log(e)
      if (!m.fromMe) return m.reply(Func.jsonFormat(new Error('encountered an error :' + e)))
   }
   Func.reload(require.resolve(__filename))
}

async function cekStatusPembayaran(uniqueCode) {
   try {
      const key = global.apikey_paydisini;
      const signature = md5(`${key}${uniqueCode}StatusTransaction`);

      const formdata = new URLSearchParams();
      formdata.append("key", key);
      formdata.append("request", "status");
      formdata.append("unique_code", uniqueCode);
      formdata.append("signature", signature);

      const requestOptions = {
         method: 'POST',
         body: formdata,
         redirect: 'follow'
      };

      const response = await fetch("https://paydisini.co.id/api/", requestOptions);
      const result = await response.json();

      return result.data.status;
   } catch (error) {
      console.error(`Error occurred while checking payment status for unique_code ${uniqueCode}: ${error.message}`);
      return 'Error';
   }
}
