const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');
const md5 = require('md5');

exports.run = {
    usage: ['beli'],
    hidden: ['buy'],
    use: 'code|amount',
    category: 'shop',
    async: async (m, { client, env, args, isPrefix, text, command, Func, setting, users }) => {
        const number = `${m.sender.replace(/@.+/g, '')}`
        const [code, amount] = text.split('|');
        if (!code || isNaN(amount)) {
            return client.reply(m.chat, `🚩 *Format salah!*\n\n• Penggunaan : ${isPrefix + command} code|jumlah\n• Contoh : ${isPrefix + command} TT200|2`, m);
        }

        if (!users) return client.reply(m.chat, '🚩 Pengguna tidak ditemukan.', m);

        // Path ke file produk.json
        const produkFilePath = path.join('lib', 'database', 'produk.json');
        // Path ke file tt200.json (atau sesuai dengan kode produk)
        const codeFilePath = path.join('lib', 'database', 'data', `${code.toLowerCase()}.json`);

        try {
            // Baca file produk.json
            const produkData = JSON.parse(fs.readFileSync(produkFilePath, 'utf8'));

            // Cek apakah produk dengan kode tersebut ada
            const produkKey = Object.keys(produkData.produk).find(key => key.endsWith(`°${code.toUpperCase()}`));
            if (!produkKey) return client.reply(m.chat, '🚩 Produk tidak ditemukan.', m);
            // Cek apakah stok mencukupi
            const produk = produkData.produk[produkKey];
            if (produk.stok < amount) {
                return client.reply(m.chat, '🚩 Stok tidak mencukupi.', m);
            }

            const [judul, hargaStr, kodeProduk] = produkKey.split('°');
            const harga = parseInt(hargaStr);
            const total = harga * parseInt(amount);
            const selisih = total - users.deposit;
            const note = `${number} membeli produk ${judul} sebanyak ${Func.formatNumber(amount)}`;

            if (users.deposit < total) {
                client.reply(m.chat, `🚩 Saldo kamu tidak mencukupi. Saldo kamu kurang Rp. ${Func.formatNumber(selisih)}
                
> Silahkan melakukan pembayaran berikut untuk melakukan pembelian`, m);

                function generateRandomString(length) {
                    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
                    let result = '';
                    for (let i = 0; i < length; i++) {
                        result += characters.charAt(Math.floor(Math.random() * characters.length));
                    }
                    return result;
                }
                
                const randomString = generateRandomString(16);

                // Prepare parameters for payment QR code
                let key = global.apikey_paydisini;
                let service = global.channel;
                let validTime = "1800";
                let typeFee = "1";
                let signature = md5(`${key}${randomString}${service}${selisih}${validTime}NewTransaction`);

                // Prepare payload for API request
                let formdata = new URLSearchParams();
                formdata.append("key", key);
                formdata.append("request", "new");
                formdata.append("unique_code", randomString);
                formdata.append("service", service);
                formdata.append("amount", selisih);
                formdata.append("note", note);
                formdata.append("valid_time", validTime);
                formdata.append("type_fee", typeFee);
                formdata.append("signature", signature);

                // Make request to Paydisini API
                let requestOptions = {
                    method: 'POST',
                    body: formdata,
                    redirect: 'follow'
                };

                // Send request and handle response
                let response = await fetch("https://paydisini.co.id/api/", requestOptions);
                let result = await response.json();

                // Get the QR code URL from the API response
                const qrcodeUrl = result.data.qrcode_url;

                var buttons = [{
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                        title: "Choose an option",
                        sections: [{
                            rows: [{
                                title: "Cancel Deposit",
                                description: '',
                                id: `${isPrefix}cancel-beli`
                            }, {
                                title: "Cek Status",
                                description: '',
                                id: `${isPrefix}check`
                            }]
                        }]
                    })
                }];

                // Send QR code URL as a message
                await client.sendFile(number + '@c.us', qrcodeUrl, 'qrcode.png', `*❒  QRIS PAYDISINI*

Pay Id : *${result.data.pay_id}*
Status : *Pending 🕘*
Unique Code: *${randomString}*
Total Pembayaran : *Rp. ${Func.formatNumber(result.data.amount)}*

Note : _${note}_

○ Silahkan scan *Qris* tersebut menggunakan ewallet / bank dan melakukan pembayaran
○ *Qris* Expired 30 menit
○ Setelah melakukan pembayaran, kirim pesan *check* untuk mengecek status pembayaran
○ Jika status pembayaran *Success*, maka secara otomatis produk akan dikirimkan
○ Jika ingin membatalkan pengisian deposit, kirim *cancel-beli*
○ Jika terjadi kendala / lainnya, hubungi *Owner*

${global.footer}`, m).then(() => client.sendIAMessage(number + '@c.us', buttons, null, {
                    header: '',
                    content: '',
                    footer: '',
                    media: ''
                })).then(() => client.sendReact(m.chat, '✅', m.key));

                // Update user's unique code for reference
                users.unique = randomString;

                // Users
                users.unique_beli = randomString;
                users.status_beli = true;

                // Path to beli.json file
                const jalur = path.join('lib', 'database', 'beli.json');

                // Read beli.json content if exists
                let data = {};
                if (fs.existsSync(jalur)) {
                    const fileContent = fs.readFileSync(jalur, 'utf8');
                    try {
                        data = JSON.parse(fileContent);
                    } catch (error) {
                        console.error('Error parsing beli.json:', error);
                    }
                }

                // Add new data based on randomString
                data[randomString] = {
                    "code_produk": code.toLowerCase(),
                    "amount": parseInt(amount),
                    "nomor": parseInt(number)
                };

                // Write back to beli.json
                fs.writeFile(jalur, JSON.stringify(data, null, 2), (err) => {
                    if (err) {
                        console.error('Error writing beli.json:', err);
                    } else {
                        console.log(`Data successfully added to beli.json for randomString '${randomString}'.`);
                    }
                });

                if (m.isGroup) {
                    client.reply(m.chat, '✅ Aktivasi deposit telah dikirim pada private Chat', m);
                }

                return; // Stop further processing
            }

            // Baca file code.json
            let codeData = JSON.parse(fs.readFileSync(codeFilePath, 'utf8'));

            // Kirim pesan sebanyak amount dan hapus data yang dikirimkan
            const codesToSend = codeData.splice(0, amount);
            for (let i = 0; i < codesToSend.length; i++) {
                let number = `${m.sender.replace(/@.+/g, '')}`
                await client.reply(number + '@c.us', codesToSend[i], m);
            }

            // Simpan perubahan ke dalam file code.json
            fs.writeFileSync(codeFilePath, JSON.stringify(codeData, null, 2), 'utf8');

            // Kasus pengguna
            users.deposit -= harga * amount;
            users.total_pengeluaran += harga * amount;
            users.total_pembelian += parseInt(amount);

            // Kurangi stok produk
            produk.stok -= parseInt(amount);
            produk.stok_terjual += parseInt(amount);

            // Simpan perubahan ke dalam produk.json
            fs.writeFileSync(produkFilePath, JSON.stringify(produkData, null, 2), 'utf8');

            client.reply(m.chat, `✅ Pembelian berhasil.

- Produk : ${judul}
- Jumlah Pembelian : ${amount}
- Total Harga : Rp. ${Func.formatNumber(harga * amount)}

> _Terimakasih Atas Pembeliannya Di ${env.merchant}_

${global.footer}`, m).then(() => client.reply(env.owner + '@c.us', `🔴 *NOTIFIKASI*

@${number} Membeli produk - *${judul}*
- Jumlah Pembelian : ${amount}
- Total Pembelian : Rp. ${Func.formatNumber(harga * amount)}
- Sisa Stok Produk : ${Func.formatNumber(produk.stok)}

${global.footer}`, m));
        } catch (error) {
            console.error('Error in beli request:', error);
            client.reply(m.chat, '❌ Terjadi kesalahan saat melakukan pembelian.', m);
        }
    },
    error: false,
    location: __filename
};

