exports.run = {
   usage: ['menu'],
   async: async (m, {
      client,
      isPrefix,
      command,
      env,
      users,
      Func, 
      setting
   }) => {
      try {
         let readmore = String.fromCharCode(8206).repeat(4001)
         const buttons = [{
            name: 'single_select',
            buttonParamsJson: JSON.stringify({
               title: 'Utilities',
               sections: [{
                  title: 'Utilities',
                  rows: [{
                     title: 'List Panel',
                     id: `${isPrefix}listpanel`
                  }],
               }, {
                  rows: [{
                     title: 'All Menu',
                     id: `${isPrefix}allmenu`
                  }],
               }, {
                  rows: [{
                     title: 'All Product',
                     id: `${isPrefix}produk`
                  }],
               }]
            })
         }, {
            name: 'single_select',
            buttonParamsJson: JSON.stringify({
               title: 'Product',
               sections: [{
                  title: 'Judul',
                  rows: [{
                     title: 'Nama Produk 1',
                     description: `Deskripsi Produk 1`,
                     id: `${isPrefix}get a`
                  }],
                  highlight_label: 'Produk Terlaris'
               }, {
                  rows: [{
                     title: 'Nama Produk 2',
                     description: `Deskripsi Produk 2`,
                     id: `${isPrefix}get b`
                  }],
               }, {
                  rows: [{
                     title: 'Nama Produk 3',
                     description: `Deskripsi Produk 3`,
                     id: `${isPrefix}get c`
                  }],
                  highlight_label: 'Produk Terlaris'
               }, {
                  rows: [{
                     title: 'Nama Produk 4',
                     description: `Deskripsi Produk 4`,
                     id: `${isPrefix}get d`
                  }],
               }, {
                  rows: [{
                     title: 'Nama Produk 5',
                     description: `Deskripsi Produk 5`,
                     id: `${isPrefix}get e`
                  }],
                  highlight_label: 'Produk Terbaru'
               }, {
                  title: 'Judul 2',
                  rows: [{
                     title: 'Nama Produk 1',
                     description: `Deskripsi Produk 1`,
                     id: `${isPrefix}get a`
                  }],
                  highlight_label: 'Promo!'
               }, {
                  rows: [{
                     title: 'Nama Produk 2',
                     description: `Deskripsi Produk 2`,
                     id: `${isPrefix}get b`
                  }],
               }, {
                  rows: [{
                     title: 'Nama Produk 3',
                     description: `Deskripsi Produk 3`,
                     id: `${isPrefix}get c`
                  }],
                  highlight_label: 'Produk Terlaris'
               }, {
                  rows: [{
                     title: 'Nama Produk 4',
                     description: `Deskripsi Produk 4`,
                     id: `${isPrefix}get d`
                  }],
                  highlight_label: 'Produk Terbaru' 
               }, {
                  rows: [{
                     title: 'Nama Produk 5',
                     description: `Deskripsi Produk 5`,
                     id: `${isPrefix}get e`
                  }],
               }]
            })
         }]

const st = setting.style

if (st === 1) return client.sendMessageModifyV2(m.chat, `*Hallo @${m.sender.replace(/@.+/g, '')}👋*

*👤 PROFILE*
• Name : *${m.pushName}*
• Saldo : *Rp. ${Func.formatNumber(users.deposit)}*
• Total Pembelian : *${Func.formatNumber(users.total_pembelian)}*
• Total Pengeluaran : *Rp. ${Func.formatNumber(users.total_pengeluaran)}* ${readmore}


╭─━─〘 *PRODUK 1* 〙
│∘ Harga : *Rp. 9,999*
│∘ Stok Tersedia : 50
│∘ Stok Terjual : 50
│∘ Total Stok : 100
│∘ Kode : P1
│∘ Desk : Deskripsi Produk 1
╰─━─━─━─━─━─≫

╭─━─〘 *PRODUK 2* 〙
│∘ Harga : *Rp. 9,999*
│∘ Stok Tersedia : 50
│∘ Stok Terjual : 50
│∘ Total Stok : 100
│∘ Kode : P1
│∘ Desk : Deskripsi Produk 2
╰─━─━─━─━─━─≫

╭─━─〘 *PRODUK 3* 〙
│∘ Harga : *Rp. 9,999*
│∘ Stok Tersedia : 50
│∘ Stok Terjual : 50
│∘ Total Stok : 100
│∘ Kode : P1
│∘ Desk : Deskripsi Produk 3
╰─━─━─━─━─━─≫

╭─━─〘 *PRODUK 1* 〙
│∘ Harga : *Rp. 9,999*
│∘ Stok Tersedia : 50
│∘ Stok Terjual : 50
│∘ Total Stok : 100
│∘ Kode : P1
│∘ Desk : Deskripsi Produk 4
╰─━─━─━─━─━─≫

╭─━─〘 *PRODUK 5* 〙
│∘ Harga : *Rp. 9,999*
│∘ Stok Tersedia : 50
│∘ Stok Terjual : 50
│∘ Total Stok : 100
│∘ Kode : P1
│∘ Desk : Deskripsi Produk 5
╰─━─━─━─━─━─≫`, m.pushName, {
   title: env.bot_name,
   largeThumb: true,
   ads: true,
   thumbnail: global.db.setting.cover,
   url: global.db.setting.link
}) 

if (st === 2) return client.sendMessageModifyV2(m.chat, `*Hallo @${m.sender.replace(/@.+/g, '')}👋*

*👤 PROFILE*
• Name : *${m.pushName}*
• Saldo : *Rp ${Func.formatNumber(users.deposit)}*
• Total Pembelian : *${Func.formatNumber(users.total_pembelian)}*
• Total Pengeluaran : *Rp. ${Func.formatNumber(users.total_pengeluaran)}*`, m.pushName, {
   title: env.bot_name,
   largeThumb: true,
   ads: true,
   thumbnail: global.db.setting.cover,
   url: global.db.setting.link
}).then(() => client.sendIAMessage(m.chat, buttons, null, {
            header: ``,
            content: `Berikut Adalah Produk Jualan Kami`,
            footer: global.footer,
            media: ''
         }))
      } catch (e) {
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   cache: true,
   location: __filename
}

