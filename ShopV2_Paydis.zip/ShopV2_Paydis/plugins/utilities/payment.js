exports.run = {
   usage: ['payment'],
   category: 'utilities',
   async: async (m, {
      client,
      Func, 
      setting
   }) => {
      try {
         client.sendReact(m.chat, '🕘', m.key).then(() => client.sendFile(m.chat, setting.qris, '', setting.payment + `\n\nTransfer sesuai nominal deposit yang diinginkan, lalu kirim bukti pembayaran ke owner. Owner akan menambahkan saldo deposit sesuai nominal yang ditransfer.`, m)).then(() => client.sendReact(m.chat, '✅', m.key))
      } catch (e) {
         return console.log(e)
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   cache: false,
   location: __filename
}