exports.run = {
   usage: ['deposit'],
   use: 'amount',
   category: 'utilities',
   async: async (m, { client, args, isPrefix, command, setting, Func, users }) => {
      try {
         users.jumlah = 0
         let amount = args[0]
         if (!amount) return client.reply(m.chat, Func.example(isPrefix, command, '1000'), m)
         if (isNaN(amount)) return client.reply(m.chat, Func.example(isPrefix, command, '1000'), m)
         if (amount < 1000) {
            return client.reply(m.chat, '*🚩 Deposit minimal di atas Rp 1000*', m);
         }
var buttons = [{
    name: "single_select",
    buttonParamsJson: JSON.stringify({
        title: "OPSI DEPOSIT",
        sections: [{
            rows: [{
                header: 'QRIS V1',
                title: 'Fee 0,7%',
                description: 'Qris All Payment - Ewallet',
                id: `${isPrefix}deposit1 ${amount}`
            }, {
                header: 'Manual',
                title: 'Top Up Langsung Ke Owner',
                description: 'Via Top Up Ewallet / Pulsa',
                id: `${isPrefix}payment`
            }]
        }]
    })
}]
client.sendIAMessage(m.chat, buttons, m, {
    header: 'OPSI DEPOSIT\n',
    content: 'Pilih Opsi Deposit Berikut\n',
    footer: global.footer,
    media: global.db.setting.cover
})
      } catch (e) {
         console.error(e);
         await client.reply(m.chat, `Terjadi kesalahan: ${e.message}`, m);
      }
   },
   error: false,
   location: __filename
};