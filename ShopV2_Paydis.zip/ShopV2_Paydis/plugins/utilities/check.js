const axios = require('axios');
const FormData = require('form-data');
const md5 = require('md5');
const fs = require('fs');
const path = require('path');

exports.run = {
  usage: ['check'],
  async: async (m, { client, users, command, isPrefix }) => {
    try {
      if (users.status_beli) {
        let uniqueCode = users.unique_beli;
        if (!uniqueCode) {
          return client.reply(m.chat, `🚩 Unique code tidak ditemukan untuk pengguna ini.`, m);
        }

        let apiKey = global.apikey_paydisini;
        let signature = md5(apiKey + uniqueCode + 'StatusTransaction');

        // Prepare form-data
        var formdata = new FormData();
        formdata.append("key", apiKey);
        formdata.append("request", "status");
        formdata.append("unique_code", uniqueCode);
        formdata.append("signature", signature);

        const response = await axios.post('https://paydisini.co.id/api/', formdata, {
          headers: formdata.getHeaders()
        });

        if (response.data.success) {
          const transaction = response.data.data;
          let message = `🔍 *STATUS TRANSAKSI*\n\n`;
          message += `⟩ Unique Code: ${transaction.unique_code}\n`;
          message += `⟩ Status: ${transaction.status}\n`;
          message += `⟩ Amount: ${transaction.amount}\n`;
          message += `⟩ Balance: ${transaction.balance}\n`;
          message += `⟩ Fee: ${transaction.fee}\n`;
          message += `⟩ Note: ${transaction.note}\n`;
          message += `⟩ Created At: ${transaction.created_at}\n`;

          if (transaction.status.toLowerCase() === 'success') {
            client.reply(m.chat, message, m);

            // Cek jika uniqueCode ada dalam beli.json
            const beliPath = path.join('lib', 'database', 'beli.json');
            let beliData = JSON.parse(fs.readFileSync(beliPath, 'utf-8'));

            if (beliData[uniqueCode]) {
              let { code_produk, amount, nomor } = beliData[uniqueCode];

              // Path to product data file
              const produkDataPath = path.join('lib', 'database', 'data', `${code_produk}.json`);
              let produkMessages = JSON.parse(fs.readFileSync(produkDataPath, 'utf-8'));

              // Check if enough messages are available
              if (produkMessages.length < amount) {
                client.reply(m.chat, `🚩 Jumlah pesan yang tersedia tidak mencukupi.`, m);
                return;
              }

              // Send the messages
              for (let i = 0; i < amount; i++) {
                let messageToSend = produkMessages.shift();
                client.reply(nomor + '@c.us', messageToSend, null);
              }

              // Update the produk data file after sending messages
              fs.writeFileSync(produkDataPath, JSON.stringify(produkMessages, null, 2));

              // Update produk.json (stok and stok_terjual)
              const produkPath = path.join('lib', 'database', 'produk.json');
              let produkData = JSON.parse(fs.readFileSync(produkPath, 'utf-8'));
              for (let key in produkData.produk) {
                if (key.split('°')[2] === code_produk.toUpperCase()) {
                  produkData.produk[key].stok -= amount;
                  produkData.produk[key].stok_terjual += amount;
                  break;
                }
              }
              fs.writeFileSync(produkPath, JSON.stringify(produkData, null, 2));

              // Remove transaction data from beli.json
              delete beliData[uniqueCode];
              fs.writeFileSync(beliPath, JSON.stringify(beliData, null, 2));

              users.unique_beli = '';
              users.status_beli = false;
              users.deposit = 0;

              client.reply(env.owner + '@c.us', `🔴 *NOTIFIKASI*

○ Note : *${note}*

${global.footer}`, m);
            } else {
              client.reply(m.chat, `🚩 Transaksi dengan uniqueCode ${uniqueCode} tidak ditemukan dalam beli.json.`, m);
            }
          } else {
            client.reply(m.chat, `🚩 Status pembayaran masih Pending.`, m);
          }
        } else {
          client.reply(m.chat, `🚩 ${response.data.msg}`, m);
        }
      }
    } catch (e) {
      console.error(e);
      return client.reply(m.chat, '🚩 Terjadi kesalahan dalam menjalankan permintaan Anda.', m);
    }
  },
  owner: false,
  cache: true,
  location: __filename
};
