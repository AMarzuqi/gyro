const axios = require('axios');
const FormData = require('form-data');
const md5 = require('md5');
const fs = require('fs');
const path = require('path');

exports.run = {
  usage: ['cekstatus'],
  category: 'features',
  async: async (m, { client, users, command, isPrefix, Func }) => {
    try {
      if (users.status_deposit) {
      let uniqueCode = users.unique;
      if (!uniqueCode) {
        return client.reply(m.chat, `🚩 Unique code tidak ditemukan untuk pengguna ini.`, m);
      }

      let apiKey = global.apikey_paydisini;
      let signature = md5(apiKey + uniqueCode + 'StatusTransaction');

      // Prepare form-data
      var formdata = new FormData();
      formdata.append("key", apiKey);
      formdata.append("request", "status");
      formdata.append("unique_code", uniqueCode);
      formdata.append("signature", signature);

      const response = await axios.post('https://paydisini.co.id/api/', formdata, {
        headers: formdata.getHeaders()
      });

      if (response.data.success) {
        const transaction = response.data.data;
        let message = `🔍 *STATUS TRANSAKSI*\n\n`;
        message += `⟩ Unique Code: ${transaction.unique_code}\n`;
        message += `⟩ Status: ${transaction.status}\n`;
        message += `⟩ Amount: ${transaction.amount}\n`;
        message += `⟩ Balance: ${transaction.balance}\n`;
        message += `⟩ Fee: ${transaction.fee}\n`;
        message += `⟩ Note: ${transaction.note}\n`;
        message += `⟩ Created At: ${transaction.created_at}\n`;

        if (transaction.status.toLowerCase() === 'success') {
          client.reply(m.chat, message, m);

          // Cek jika uniqueCode ada dalam transaksi.json
          const transaksiPath = path.join('lib', 'database', 'transaksi.json');
          let transaksi = JSON.parse(fs.readFileSync(transaksiPath, 'utf-8'));

          if (transaksi[uniqueCode]) {
            let number = m.sender.replace(/@.+/g, '');
            let target = global.db.users.find(v => v.jid === number + '@s.whatsapp.net');
            let balance = transaksi[uniqueCode].balance;

            if (target) {
              target.deposit += balance;

              // Hapus data transaksi setelah saldo ditambahkan
              delete transaksi[uniqueCode];
              fs.writeFileSync(transaksiPath, JSON.stringify(transaksi, null, 2));

              client.reply(m.chat, `✅ Saldo sebesar Rp. ${Func.formatNumber(balance)} berhasil ditambahkan ke akun Anda.`, m);
        users.payexpired = '';
        users.depo_opt = false;
        users.status_deposit = false;
        users.unique = '';
        users.note = '';
        users.create = '', 
        users.total_pembayaran = '';
        users.jumlah = '';
        users.payid = '';
            } else {
              client.reply(m.chat, `🚩 Pengguna dengan nomor ${number} tidak ditemukan dalam database.`, m);
            }
          } else {
            client.reply(m.chat, `🚩 Transaksi dengan uniqueCode ${uniqueCode} tidak ditemukan dalam transaksi.json.`, m);
          }
        } else {
          client.reply(m.chat, `🚩 Status pembayaran masih Pending.`, m);
        }
      } else {
        client.reply(m.chat, `🚩 ${response.data.msg}`, m);
      }
      }
    } catch (e) {
      console.error(e);
      return client.reply(m.chat, '🚩 Terjadi kesalahan dalam menjalankan permintaan Anda.', m);
    }
  },
  owner: false,
  cache: true,
  location: __filename
};