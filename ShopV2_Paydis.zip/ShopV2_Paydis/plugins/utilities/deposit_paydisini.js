const fetch = require('node-fetch');
const md5 = require('md5');
const fs = require('fs');

exports.run = {
    usage: ['deposit1'],
    use: 'amount',
    category: 'utilities',
    async: async (m, { client, args, isPrefix, command, Func, setting, users }) => {
        try {
            let number = m.sender.replace(/@.+/g, '');
            if (users.status_deposit) {
                return client.reply(m.chat, `🚩 Kamu masih memiliki aktivitasi deposit yang belum selesai.

Batal kan status deposit / selesaikan pembayaran terlebih dahulu`, null);
            }
            let amount = args[0];
            if (isNaN(amount)) return client.reply(m.chat, Func.example(isPrefix, command, '1000'), null);
            if (amount < 100) return client.reply(m.chat, '🚩 Minimal deposit Rp. 100', null);
            let note = `${number} Deposit Sebesar Rp. ${Func.formatNumber(amount)}`;

            client.sendReact(m.chat, '🕘', m.key);

            function generateRandomString(length) {
                const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
                let result = '';
                for (let i = 0; i < length; i++) {
                    result += characters.charAt(Math.floor(Math.random() * characters.length));
                }
                return result;
            }

            const randomString = generateRandomString(16);

            // Menyiapkan parameter untuk request
            let key = global.apikey_paydisini;
            let service = global.channel;
            let validTime = "1800";
            let typeFee = "1";
            let signature = md5(`${key}${randomString}${service}${amount}${validTime}NewTransaction`);

            // Membuat payload untuk request
            let formdata = new URLSearchParams();
            formdata.append("key", key);
            formdata.append("request", "new");
            formdata.append("unique_code", randomString);
            formdata.append("service", service);
            formdata.append("amount", amount);
            formdata.append("note", note);
            formdata.append("valid_time", validTime);
            formdata.append("type_fee", typeFee);
            formdata.append("signature", signature);

            // Membuat request ke API Paydisini
            let requestOptions = {
                method: 'POST',
                body: formdata,
                redirect: 'follow'
            };

            // Mengirimkan request dan menangani responsenya
            let response = await fetch("https://paydisini.co.id/api/", requestOptions);
            let result = await response.json();

            // Cek Data
            let total = result.data.amount;
            let payID = result.data.pay_id;
            let create = result.data.created_at;
            let expired = result.data.expired;
            let qrcode_url = result.data.qrcode_url;

            var buttons = [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Choose an option",
                    sections: [{
                        rows: [{
                            title: "Cancel Deposit",
                            description: '',
                            id: `.cancel-deposit`
                        }, {
                            title: "Cek Status",
                            description: '',
                            id: `.cekstatus`
                        }]
                    }]
                })
            }];

            // Kirim QR code sebagai pesan
            await client.sendFile(number + '@c.us', qrcode_url, 'qrcode.png', `*❒ QRIS PAYDISINI*

Pay Id : ${payID}
Status : *Pending 🕘*
Unique Code: *${randomString}*
Jumlah : *Rp. ${Func.formatNumber(amount)}*
Total Pembayaran : *Rp. ${Func.formatNumber(total)}*

Note : ${note}

Create : *${create}*
Expired : *${expired}*

○ Silahkan scan *Qris* tersebut menggunakan ewallet / bank dan melakukan pembayaran
○ *Qris* Expired 30 menit
○ Setelah melakukan pembayaran, kirim pesan *cekstatus* untuk mengecek status pembayaran
○ Jika status pembayaran *Success*, maka secara otomatis saldo deposit akan bertambah sebesar *Rp. ${Func.formatNumber(args[0])}*
○ Jika ingin membatalkan pengisian deposit, kirim *cancel-deposit*
○ Jika terjadi kendala / lainnya, hubungi *Owner*

${global.footer}`, null).then(() => client.sendReact(m.chat, '✅', m.key));

            if (m.isGroup) {
                client.reply(m.chat, '✅ Aktivasi deposit telah dikirim pada private Chat', null);
            }

            users.payexpired = expired;
            users.create = create;
            users.total_pembayaran = total;
            users.jumlah = amount;
            users.payid = payID;
            users.deposit_options = false;
            users.note = note;
            users.unique = randomString;
            users.status_deposit = true;

            // Tambahkan data unique_code ke transaksi.json
            let transaksiData = fs.readFileSync('./lib/database/transaksi.json', 'utf8');
            let transaksi = JSON.parse(transaksiData);
            transaksi[randomString] = { balance: users.deposit + result.data.balance, nomor: `${m.sender.replace(/@.+/g, '')}` };
            fs.writeFileSync('./lib/database/transaksi.json', JSON.stringify(transaksi, null, 2));

        } catch (e) {
            console.log(e);
            client.reply(m.chat, Func.jsonFormat(e), null);
        }
    },
    error: false,
    location: __filename
};